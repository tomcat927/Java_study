package com.example.troubleshoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TroubleshootDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(TroubleshootDemoApplication.class, args);
    }

}
