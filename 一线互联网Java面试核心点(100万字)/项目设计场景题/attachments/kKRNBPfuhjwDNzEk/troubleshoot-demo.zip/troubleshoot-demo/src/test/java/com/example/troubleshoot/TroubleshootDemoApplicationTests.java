package com.example.troubleshoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TroubleshootDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
